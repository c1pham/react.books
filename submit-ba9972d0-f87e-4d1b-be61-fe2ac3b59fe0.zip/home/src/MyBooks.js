import React, { Component } from 'react';
import Shelf from './Shelf';
import {Link} from 'react-router-dom';

class MyBooks extends Component {
    /**
	* @description Renders the book shelves
	*/
    render() {
        const {shelves, reloadBooks} = this.props;
        return <div className='list-books'>
            <div className='list-books-title'>
                <h1>MyReads</h1>
            </div>

            <div className='list-books-content'>
                <div>
                    {shelves.map((shelf)=>{ // generate shelves
                        return <Shelf key={shelf.key} title= {shelf.shelfTitle} books={shelf.books} refresh={reloadBooks}/>;
                    })}
                </div>
            </div>

            <div className='open-search'>
                <Link to='/search'>Add a book</Link>
            </div>
        </div>;
    }
}

export default MyBooks;