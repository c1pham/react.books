import React from 'react';
import './App.css';
import * as BooksAPI from './BooksAPI';
import {Route} from 'react-router-dom';


import SearchPage from './SearchPage';
import MyBooks from './MyBooks';


class BooksApp extends React.Component {
	state = {
    shelves : [],
    searchResults: [],
    showSearchPage: false
	};

  /**
  * @description Clears out the search books
  */
  clearSearchBooks = () => {
    this.setState({'searchResults': []});
  }

  /**
  * @description Gets the search books
  */
	getSearchBooks = () => {
		const query = document.getElementById('search-bar').value;
		if (query !== '') { // if not empty then make search
			BooksAPI.search(query).then( (result)=>{
				if (result.error === 'empty query') { // no results
					this.clearSearchBooks();
				} else {
					BooksAPI.getAll().then((myBooks)=>{
            myBooks.forEach(function(myBook){ // determine which shelf it belongs on
              result.forEach(function(searchBook){
                if (myBook.id === searchBook.id) { // if the book on our shelf matches a book from search then set the shelf key
									searchBook.shelf = myBook.shelf;
								}
              });
            });
            var filteredResults = result.filter((book)=>{  // remove any books without thumbnails
              return book.imageLinks!== undefined && book.imageLinks.thumbnail !== undefined;
            });
            const currentQuery = document.getElementById('search-bar').value;
            if (query === currentQuery ) { // some queries return faster than others but we only want update on current query value
              this.setState({'searchResults': filteredResults});
              this.reloadBooks();
            }
					});
				}
			});
		} else {
      this.clearSearchBooks();
    }
	}

  /**
  * @description This will make a API call and will take our books and put them into shelves
  */
	reloadBooks = () => {
		BooksAPI.getAll().then((result)=>{
			const data = result;
			const tmpShelves = {
        'currentlyReading': {
          'shelfTitle': 'Currently Reading',
          'books': []
        },
        'wantToRead': {
          'shelfTitle': 'Want to Read',
          'books': []
        },
        'read': {
          'shelfTitle': 'Read',
          'books': []
        }
			};

			data.forEach(function(book) {  // take results and put in shelf
        tmpShelves[(book.shelf)].books.push(book);
			});

			const outputShelves = [];

      Object.keys(tmpShelves).forEach(function(key) {  // make it so each individual book records what shelf it is on
        var shelf = tmpShelves[key];
        shelf['key'] = key;
        outputShelves.push(shelf);
      });

			this.setState({'shelves': outputShelves});
		});
	}

  /**
  * @description When this component mounts then reload the books
  */
	componentDidMount() {
		this.reloadBooks();
	}

  /**
  * @description Renders the application
  */
	render() {
		const {shelves, searchResults} = this.state;
		return (
      <div className='app'>
        <Route exact path='/' render={() => (
          <MyBooks shelves={shelves} reloadBooks={this.reloadBooks}/>
        )}/>
        <Route exact path='/search' render={() => (
          <SearchPage clearSearchBooks={this.clearSearchBooks} shelves={shelves} searchResults={searchResults} reloadBooks={this.reloadBooks} getSearchBooks={this.getSearchBooks}/>
        )}/>
      </div>
		);
	}
}

export default BooksApp;
