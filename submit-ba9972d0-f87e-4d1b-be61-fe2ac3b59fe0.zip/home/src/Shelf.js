import React, { Component } from 'react';
import Book from './Book';

class Shelf extends Component {
	/**
	* @description Renders the shelf
	*/
	render() {
		const {books, title, refresh} = this.props;

		return <div className='bookshelf'>
      <h2 className='bookshelf-title'>{title}</h2>
      <div className='bookshelf-books'>
        <ol className='books-grid'>
          {books.map((book)=>{
            return <li key={book.id}>
              <Book book={book} title= {book.title} author={book.author} imageUrl={book.imageLinks.thumbnail} id={book.id} refresh={refresh}/>
            </li>;
          })}
        </ol>
      </div>
		</div>;
	}
}

export default Shelf;