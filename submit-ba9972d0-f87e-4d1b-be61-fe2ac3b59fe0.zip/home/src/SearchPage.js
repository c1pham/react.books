import React, { Component } from 'react';
import Book from './Book';
import { Link } from 'react-router-dom';

class SearchPage extends Component {
    /**
	* @description When component mounts clear the existing search books
	*/
    componentDidMount() {
		const { clearSearchBooks } = this.props;
        clearSearchBooks();
	}

    /**
	* @description Renders the searchpage
	*/
	render() {
		const {searchResults, reloadBooks, getSearchBooks} = this.props;
		return  <div className='search-books'>
            <div className='search-books-bar'>
                <Link className='close-search' to='/'>Close</Link>
                <div className='search-books-input-wrapper'>
                    <input id='search-bar' type='text' placeholder='Search by title or author' onChange={() => {getSearchBooks()}}/>
                    <ol className='books-grid'>
                        {searchResults.map((book)=>{
                            return <li key={book.id}>
                                <Book book={book} title= {book.title} author={book.author} imageUrl={book.imageLinks.thumbnail} id={book.id} refresh={reloadBooks}/>
                            </li>;
                        })}
                    </ol>
                </div>
            </div>
            <div className='search-books-results'>
                <ol className='books-grid'></ol>
            </div>
		</div>;
	}
}

export default SearchPage;