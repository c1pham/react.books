import React, { Component } from 'react';
import * as BooksAPI from './BooksAPI';

class Book extends Component {
	state = {
		'shelf': this.props.book.shelf
	}

	/**
	* @description Moves book to another shelf
	*/
	moveBook = () => {
		const {book, id, refresh} = this.props;

		const shelf = document.getElementById('select-' + id).value; // get shelf that is selected

		BooksAPI.update(book, shelf).then(()=>{ // update in database where book is
			refresh();
			this.setState({'shelf': shelf});
		});
	}


	/**
	* @description Renders the book
	*/
	render() {
		const {imageUrl, title, author, id} = this.props;
		const shelf = this.state.shelf;

		var options = [
            {
				'name': 'move',
				'description': 'Move to...'
			},
            {
				'name': 'currentlyReading',
				'description': 'Currently Reading'
			},
            {
				'name': 'wantToRead',
				'description': 'Want to Read'
			},
            {
				'name': 'read',
				'description': 'Read'
			},
            {
				'name': 'none',
				'description': 'None'
			}
		];

		return  <div className='book'>
		    <div className='book-top'>
            <div className='book-cover' style={{ width: 128, height: 193, backgroundImage: 'url("' + imageUrl +'")' }}></div>
            <div className='book-shelf-changer'>
                <select id={'select-' + id} onChange={() => this.moveBook()}>
                    {options.map((option)=>{ // will look at shelf and decide if a X mark is needed meaning it is selected
                        return (option.name === shelf) ? <option key={option.name} defaultValue='selected' value={option.name}> {option.description} (X) </option>
							: (option.name === 'none') && shelf === undefined ? <option key={option.name} value={option.name}> {option.description} (X) </option>
							: <option key={option.name} value={option.name}> {option.description} </option>
                    })}
                </select>
            </div>
            </div>
            <div className='book-title'>{title}</div>
            <div className='book-authors'>{author}</div>
		</div>;
	}
}

export default Book;